require('dotenv').config();
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// Wake endpoint
app.get('/', (req,res)=>res.send('Server awake ✅'));

// Sample API
app.get('/api/videos', (req,res)=>{
  res.json([
    {title:"Demo Video", path:"demo.mp4"}
  ]);
});

// Stream route
app.get('/stream/:file', (req,res)=>{
  res.send("Streaming not implemented in demo");
});

app.listen(PORT, ()=>console.log("Server running on "+PORT));
